#include "mvc2api.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>

#ifdef WIN32
#include <Windows.h>
#elif defined MM_LINUX
#include <unistd.h>
#define Sleep(x) sleep(x)
#else
#define Sleep(x) sleepms(x*1000)
#endif

using namespace mvc2;

int main(int argc, char **argv)
{
	TMmRc ret;

	if (argc < 2)
	{
		printf("MVC200-DC overlay demo\n");
		printf("%s <font>\n",argv[0]);
		exit(0);
	}

	// use first card example
	MvcDevice mvcdevice;
	if (!(mvcdevice = MvcDeviceIterator().getIndex(0)))
	{
		printf("MVC card not found\n");
		exit(0);
	}

	OverlayDecoder overlaydec(&ret, mvcdevice);
	if (MM_IS_ERROR(ret))
	{
		printf("failed to create Overlay decoder: %d\n",ret);
		exit(0);
	}

	// create the video output
	VideoOutput videoout(&ret, mvcdevice, VideoOutput::VideoProperty_Dual_HDTV);
	if (MM_IS_ERROR(ret))
	{
		printf("failed to create video output: %d\n",ret);
		exit(0);
	}

	// connect decoder with video output
	if (MM_IS_ERROR(ret = overlaydec.connectOutput(videoout)))
	{
		printf("failed to connect decoder with video output: %d\n",ret);
		exit(0);
	}

	PlaybackControl playctrl(&ret, mvcdevice);
	if (MM_IS_ERROR(ret))
	{
		printf("failed to create playback control: %d\n",ret);
		exit(0);
	}

	// connect decoder with playback
	ret = playctrl.connect(overlaydec);
	if (MM_IS_ERROR(ret))
	{
		printf("failed to connect playback control with decoder: %d\n",ret);
		exit(0);
	}

	OverlayElementDataBuffer element;
	overlaydec.getDataBuffer(element);
	if (element)
	{
		element.setElementName("overlayfont",0);
		FILE *fontfile = fopen(argv[1],"rb");
		if (fontfile)
		{
			element.send(fread(element.getBufferAddress(),1,element.getFreeSize(),fontfile));
			fclose(fontfile);
		}
		else
		{
			printf("could not open font: %s\n",argv[1]);
		}
	}

	// get overlay databuffer to setup rendering

	OverlayDataBuffer ovldatabuffer;
	overlaydec.getDataBuffer(ovldatabuffer);
	if (ovldatabuffer)
	{
		// fill an area with red color
		RenderFill fill;
		fill.setColor(0x40ff0000);
		fill.setBox(FramePosition(200,200,FramePosition::Mode_Align_Left,FramePosition::Mode_Align_Top),
			FramePosition(1600,800,FramePosition::Mode_Align_Left,FramePosition::Mode_Align_Top));
		ovldatabuffer.addRenderCommand(fill);

		// render a text of size 16 pixels
		RenderText text1("small text size");
		text1.setPosition(FramePosition(0,300,FramePosition::Mode_Align_Center,FramePosition::Mode_Align_Top));
		text1.setFont("overlayfont",16);
		ovldatabuffer.addRenderCommand(text1);

		// render a second text of size 48 pixels
		RenderText text2("big text size");
		text2.setPosition(FramePosition(0,400,FramePosition::Mode_Align_Center,FramePosition::Mode_Align_Top));
		text2.setFont("overlayfont",48);
		text2.clearRenderArea(0x8000ff00);
		ovldatabuffer.addRenderCommand(text2);

		// setup transition effect
		ovldatabuffer.setGlobalAlpha(0.5f,OverlayDataBuffer::Speed_Normal);
		ovldatabuffer.setGlobalPosition(FramePosition(100,0));
		ovldatabuffer.send();

		// wait 10 seconds
		Sleep(10000);
	}
	else
	{
		printf("failed to create overlay databuffer\n");
	}

	overlaydec.getDataBuffer(ovldatabuffer);
	if (ovldatabuffer)
	{
		// render a new text
		RenderText text1("Second render test");
		text1.setPosition(FramePosition(200,200,FramePosition::Mode_Align_Center,FramePosition::Mode_Align_Top));
		text1.setFont("overlayfont",16);
		ovldatabuffer.addRenderCommand(text1);
		ovldatabuffer.setGlobalAlpha(1.0f,OverlayDataBuffer::Speed_Normal);
		ovldatabuffer.setGlobalPosition(FramePosition(0,0));
		ovldatabuffer.send();

		Sleep(10000);
	}
	else
	{
		printf("failed to create overlay databuffer\n");
	}

	return 0;
}
