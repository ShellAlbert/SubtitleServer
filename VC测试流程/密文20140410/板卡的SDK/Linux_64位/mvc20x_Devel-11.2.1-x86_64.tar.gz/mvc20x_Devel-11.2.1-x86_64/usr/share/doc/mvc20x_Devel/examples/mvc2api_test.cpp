#include "mvc2api.h"

#pragma warning(disable : 4996)

#include <cstdio>
#include <cstdlib>
#include <cstring>

using namespace mvc2;

TMmRc transferPic(MvcDecoder& dec, char *filename, unsigned int framecount)
{
	DataBuffer datbuf;
	TMmRc ret = MMRC_Ok;
	FILE *infile;

#ifdef MM_LINUX
	infile=fopen(filename,"r");
	if(infile == NULL)
	{
		return (-1000);	
	}
#else
	if (fopen_s(&infile,filename,"rb"))
	{
		return(-1000);													// change this to 'file not found'
	}
#endif

	ret = dec.getDataBuffer(datbuf, 2*1024*1024);
	if (MM_IS_ERROR(ret))
	{
		printf("could not get databuffer -> abort\n");
		return(ret);
	}

	// copy one frame here (as an example we fill the buffer with 1's)
	uint32_t readbytes = static_cast<uint32_t>(fread(datbuf.getBufferAddress(),1,(size_t)(datbuf.getFreeSize()),infile));
	uint32_t padding = (16-(readbytes & 0x0f)) & 0x0f;
	uint8_t *buf = datbuf.getBufferAddress();
	for (uint32_t i=0;i<padding;i++)
	{
		buf[readbytes + i] = 0;
	}
//	datbuf.setUserData(framecount);
	printf("sending pic %d\n",framecount);
	datbuf.send(readbytes+padding);
	fclose(infile);
	return(ret);
}

int main(int argc, char **argv)
{
	TMmRc ret;

	if (argc < 2)
	{
		printf("specify filename with full path and printf-style number counting\n");
		printf("%s \"<path>\\%%08d\"\n",argv[0]);
		exit(0);
	}

	// MVC20x card enumeration example
	{
		MvcDeviceIterator mvcitor;
		MvcDevice mvcdev;

		while(mvcdev = mvcitor.getNext())
		{
			printf("MVC card found: UID: %d\n",mvcdev.getUID());
			NetworkInterfaceInfo netinfo;
			netinfo = mvcdev.getNetworkConfiguration();
			uint8_t ipaddr[4];
			uint8_t mac[6];
			netinfo.getIPAddress(ipaddr);
			netinfo.getMACAddress(mac);
			printf("NetworkConfiguration: %d.%d.%d.%d at MAC: %02x-%02x-%02x-%02x-%02x-%02x\n",ipaddr[0],ipaddr[1],ipaddr[2],ipaddr[3],
				mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]);
		}
	}

	// use first card example
	MvcDevice mvcdevice;
	if (!(mvcdevice = MvcDeviceIterator().getIndex(0)))
	{
		printf("MVC card not found\n");
		exit(0);
	}

	Jpeg2kDecoder j2kdec(&ret, mvcdevice);
	if (MM_IS_ERROR(ret))
	{
		printf("failed to create Jpeg2k video decoder: %d\n",ret);
		exit(0);
	}

	j2kdec.setFrameRate(24.00);			// set frame rate, so we don't need to set timestamps anymore

	// create the video output
	VideoOutput videoout(&ret, mvcdevice, VideoOutput::VideoProperty_Dual_HDTV);
	if (MM_IS_ERROR(ret))
	{
		printf("failed to create video output: %d\n",ret);
		exit(0);
	}

	// setting a video mode (optional)
	if (MM_IS_ERROR(ret = videoout.setVideoMode(VideoMode::Mode_1920_1080_2400_p)))
	{
		printf("failed to set video mode: %d\n",ret);
	}

	// connect decoder with video output
	if (MM_IS_ERROR(ret = j2kdec.connectOutput(videoout)))
	{
		printf("failed to connect decoder with video output: %d\n",ret);
		exit(0);
	}

	PlaybackControl playctrl(&ret, mvcdevice);
	if (MM_IS_ERROR(ret))
	{
		printf("failed to create playback control: %d\n",ret);
		exit(0);
	}

	// connect decoder with playback
	ret = playctrl.connect(j2kdec);
	if (MM_IS_ERROR(ret))
	{
		printf("failed to connect playback control with decoder: %d\n",ret);
		exit(0);
	}

	int framecounter = 1;
	if (argc >= 3)
	{
		sscanf(argv[2],"%i", &framecounter);
	}
	char filename[400];
	for (int i=0;i<20;i++)			// 20 picture preload before run
	{
		sprintf(filename,argv[1], framecounter);

		ret = transferPic(j2kdec, filename, framecounter++);
		if (ret)
		{
			exit(0);
		}
	}

	if (ret == MMRC_Ok)
	{
		playctrl.run();

		for (int i=0;;i++)
		{
//			printf("transfer pic %d\n",framecounter);
			sprintf(filename,argv[1],framecounter);

			ret = transferPic(j2kdec,filename,framecounter++);
//			Sleep(250);
			if (ret)
			{
				break;
			}
		}

		j2kdec.setEndOfStream();
	}

	if (ret != MMRC_Ok)
	{
		printf("picture transfer failed (%s)\n",filename);
	}

	playctrl.waitForEndOfStream();

	printf("End of stream reached\n");

	return 0;
}
